# HACCP Dokumentation App - Marmelade & Konfitüre

Diese Anwendung stellt die HACCP-Dokumentation (Gefahrenanalyse & Kritische Lenkungspunkte) als vollständige Webanwendung bereit:
- **Backend**: Python (FastAPI) mit RESTful Endpoints für Prozessschritte und CCPs.
- **Frontend**: HTML5 / JavaScript (mit Tailwind CSS) zur interaktiven Darstellung, Filterung und Überwachung.

## Schnellstart

1. **Python Abhängigkeiten installieren:**
   ```bash
   pip install fastapi uvicorn pydantic
   ```

2. **Backend starten:**
   ```bash
   python backend.py
   ```
   Der Server läuft unter `http://localhost:8000`. Die API-Dokumentation ist unter `http://localhost:8000/docs` erreichbar.

3. **Frontend öffnen:**
   Öffnen Sie die Datei `frontend.html` in einem beliebigen Webbrowser.
