from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional

app = FastAPI(title="HACCP Jam Production API", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class HACCPStep(BaseModel):
    id: str
    phase: str
    step_name: str
    hazard: str
    control_measure: str
    is_ccp: bool
    limits: str
    monitoring: str
    corrective_action: str
    verification: str
    documentation: str

haccp_database = [
    {
        "id": "1.1",
        "phase": "Wareneingang & Vorbereitung",
        "step_name": "Rohstoffe (Zucker, Obst, Pektin)",
        "hazard": "Bio: Pathogene, Keime, Schimmelpilze | Phys: Fremdkörper, Schmutz",
        "control_measure": "Lieferantenspezifikation, Audit, Sichtprüfung bei Anlieferung",
        "is_ccp": False,
        "limits": "Spezifikationskonform, intakte Gebinde",
        "monitoring": "Wareneingangsprüfer: Sichtkontrolle, Lieferscheinsprüfung",
        "corrective_action": "Waren sperren, zurückweisen, Lieferantenreklamation",
        "verification": "Lieferantenbewertung (Qualitätsmanager)",
        "documentation": "Wareneingangsprotokoll, Prüfzertifikate"
    },
    {
        "id": "1.2",
        "phase": "Wareneingang & Vorbereitung",
        "step_name": "Sortieren & Waschen",
        "hazard": "Bio: Anhaftende Mikrobiologie | Phys: Erdreste, Steine, Blätter",
        "control_measure": "Manuelles Aussortieren, gründliche Wäsche mit Trinkwasser",
        "is_ccp": False,
        "limits": "Optisch einwandfreies Obst, Trinkwasserqualität",
        "monitoring": "Produktionsmitarbeiter: Visuelle Kontrolle im Prozess",
        "corrective_action": "Nachwaschen, Nachsortieren, fehlerhaftes Obst verwerfen",
        "verification": "Tägliche Wasser- & Hygieneinspektion",
        "documentation": "Prozesskontrollblatt"
    },
    {
        "id": "2.1",
        "phase": "Thermische Verarbeitung & Konzentration",
        "step_name": "Kochen & Gelieren",
        "hazard": "Bio: Überleben vegetativer Pathogene (Salmonella, E. coli, Hefe)",
        "control_measure": "Einhaltung von Zielkerntemperatur, Haltezeit und Zuckergehalt",
        "is_ccp": True,
        "limits": "Kerntemp > 85°C (mind. 5 Min); Zuckergehalt > 60° Brix",
        "monitoring": "Anlagenführer: Kontinuierliche Tempmessung, Refraktometermessung",
        "corrective_action": "Weiterkochen bis Zielwerte erreicht; bei Anlagenausfall Chargenstopp",
        "verification": "Kalibrierung der Thermometer & Refraktometer durch QM",
        "documentation": "Kochprotokoll, Brix-Messblatt"
    },
    {
        "id": "3.1",
        "phase": "Abfüllung & Verpackung",
        "step_name": "Heissabfüllung & Verschliessen",
        "hazard": "Bio: Rekontamination im Glas/Kopfraum durch Kaltabfüllung",
        "control_measure": "Heissabfüllung, sterile/saubere Gläser nach Verschliessen wenden",
        "is_ccp": True,
        "limits": "Abfülltemperatur > 80°C am Abfüllkopf",
        "monitoring": "Abfüll-Operator: Automatische / manuelle Temp-Überwachung",
        "corrective_action": "Produkt rezirkulieren; unterkühlte Gläser ausschleusen & nacherhitzen",
        "verification": "Stichproben Vakuumprüfung & Dichtigkeit (Qualitätsmanager)",
        "documentation": "Abfüllprotokoll, Temp-Logbuch"
    },
    {
        "id": "4.1",
        "phase": "Endkontrolle",
        "step_name": "Metallkontrolle / Fremdkörper",
        "hazard": "Phys: Metallsplitter / Maschinenabrieb",
        "control_measure": "In-Line Metalldetektionssystem nach Verschliessen",
        "is_ccp": True,
        "limits": "Fe: 1,5 mm, Non-Fe: 2,0 mm, SS: 2,5 mm (kein Metall)",
        "monitoring": "QM-Mitarbeiter: Automatische Erkennung, stündlicher Testkörpercheck",
        "corrective_action": "Auswurf prüfen, betroffene Sperrcharge 100% nachprüfen",
        "verification": "Täglich Systemprüfung, Audits durch Qualitätsmanager",
        "documentation": "Metalldetektor-Prüfprotokoll, Sperrprotokoll"
    }
]

@app.get("/api/steps", response_model=List[HACCPStep])
def get_haccp_steps():
    return haccp_database

@app.get("/api/ccps", response_model=List[HACCPStep])
def get_ccps():
    return [step for step in haccp_database if step["is_ccp"]]

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
